# مختبر — Android Offline Laboratory Manager

Native Android application using Kotlin, Jetpack Compose, Material 3 and Room. Arabic-first RTL, offline-first local SQLite storage, real CRUD for patients, samples and laboratory results, test definitions, search, dashboard and settings.

## Build

Requires JDK 17+ and Android SDK Platform 35 / Build Tools 35.0.0. From the project root:

```bash
./gradlew clean
./gradlew assembleDebug
```

APK: `app/build/outputs/apk/debug/app-debug.apk`
